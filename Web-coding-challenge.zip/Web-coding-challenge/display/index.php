<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Main page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>

  <?php
      require 'header.php';
      require 'config.php';


      //we catch the ajax query using the psot method for both the liked and disliked 
      //events.
      if (isset($_POST['liked'])) {      
          $postid = $_POST['postid'];
          $sql = "INSERT INTO likee(user, shop) VALUES (?,?)";
          $query = $conn->prepare($sql);
          $query->execute(array($_SESSION['ID'],$postid));  
      }  
      if (isset($_POST['unlike'])) {      
          $postid = $_POST['postid'];
          $sql = "INSERT INTO dislike(user, shop) VALUES (?,?)";
          $query = $conn->prepare($sql);
          $query->execute(array($_SESSION['ID'],$postid)); 

          //Here we test if the cookie was already set.
          if (!isset($_COOKIE['dislikes'])) {
            # code...
            $array_dislikes=array();
            setcookie($postid, $postid, time() + (3600 * 2), "/");
            array_push($array_dislikes, $_COOKIE[$postid]);
            setcookie("array_dislikes",serialize($array_dislikes),time()+10*10*10*10*10*10);
            print_r($array_dislikes);
          }else  {
            # code...
            //here we are sure that the cookie of dislkes is set.
             array_push($array_dislikes, $_COOKIE[$postid]);
          }
        }
          ?> 
       
  ?>

  <div class="block-30 block-30-sm item" style=";" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-10">
          
          <h2 class="heading">Display shops</h2>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
      <div class="row mb-5">
        <div class="col-md-12">

          <div class="block-32">
           
              <div class="row">
              
              
                <?php
                require 'config.php';
                $sql="";
                if (isset($_COOKIE['dislikes'])) {
                   $array_cookie_dislike=$_COOKIE['dislikes'];
                   $sql="SELECT * FROM shop where ID  not in (select shop FROM likee where user =".$_SESSION['ID']."and ID not in (";

                  //if the array containes some data, cookie if not we move on the next step 
                  if (sizeof($array_dislikes)>0) {
                    # code...                  
                      foreach (array_expression as  $value){
                        //commandes
                        if (isset($_COOKIE[$value])) {
                          # code...
                          $sql_prep=$sql_prep+$_COOKIE[$value]+",";
                        }
                        
                      } 
                      # code...
                      substr($sql_prep, 0, -1);
                      $sql_prep=$sql_prep+")order by distance asc";
                  }
                  else {
                    # code...
                    $sql = "SELECT * FROM shop where ID  not in (select shop FROM likee where user =".$_SESSION['ID'].")order by distance asc";
                  }
                }
                else {
                  # code...
                  $sql = "SELECT * FROM shop where ID  not in (select shop FROM likee where user =".$_SESSION['ID'].")order by distance asc";
                
                }
                $query = $conn->prepare($sql);
                $query->execute();  
                $row = $query->fetch();
                while ($row = $query->fetch()) {        

            ?>



            <div class='col-md-6 col-lg-4' style='margin-top: 1%;margin-bottom: 1%'>
                  <div class='block-33'>
                    <div class='vcard d-flex mb-3'>                    
                        <div class='name-text align-self-center'>
                          <h2 class='heading'><?php echo $row['name']; ?></h2>                      
                        </div>
                    </div>

                    <div class='text'>
                      <blockquote>
                          <center>
                                  <img src="<?php echo $row['image']; ?>" width='70%' height='70%'>
                          </center>                                      
                      </blockquote>

                        <span><a href="" class="like" data-id="<?php echo $row['ID']; ?>">like        </a></span> 
                        <span><a href="" class="unlike" data-id="<?php echo $row['ID']; ?>">unlike </a></span> 
                    
                    </div>
                  </div>
            </div>
          <?php

          }

          ?>
                
                      

              </div>
            
            
          </div>
        </div>
      </div>

  </div>


  



<!-- Add Jquery to page -->




  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script>
  $(document).ready(function(){
    // when the user clicks on like
    
    $('.like').click(function(){
      var postid = $(this).data('id');
      //alert('you licked on ' + postid);
      $.ajax({
        url: 'index.php',
        type: 'post',
        data: {
          'liked': 1,
          'postid': postid
        },
        success: function(response){
          
        }
      });
    });

    // when the user clicks on like

    $('.unlike').click(function(){
      var postid = $(this).data('id');
      //alert('you licked on ' + postid);
      $.ajax({
        url: 'index.php',
        type: 'post',
        data: {
          'unlike': 1,
          'postid': postid
        },
        success: function(response){
          
        }
      });
    });

    
  });
</script>
</body>
</html>