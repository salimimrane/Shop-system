




-This project cotaines all the tasks asked in the Coding Challenge Guidelines https://github.com/hiddenfounders/web-coding-challenge/blob/master/coding-challenge.md using php mysql jquery and ajax.

-There is one issues in this project, when you unlike a shop the database is changed and some data are stored in the cookies but the shop still apparing in the nearby shops knowing that the cookies lifetime is 2 hours as asked. but still don't know why !

-That's all, I hope you enjoy the code.